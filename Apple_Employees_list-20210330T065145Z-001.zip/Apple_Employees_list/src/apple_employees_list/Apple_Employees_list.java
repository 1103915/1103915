/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apple_employees_list;



/**
 *
 * @author Baloch
 */
public class Apple_Employees_list {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Data_Source_codes list01 = new Data_Source_codes();
        list01.insert("John");
        list01.insert("Tim");
        list01.insert("Alina");
        list01.insert("Borner");
        list01.insert("parker");
        list01.insert("aliza");
        
        list01.traverse();
       
        System.out.println(list01.find("Tim"));
        
        list01.delete(5);
        list01.traverse();
        list01.insert("");
        
        list01.delete(1);
        list01.traverse();
       
    }
    
}
