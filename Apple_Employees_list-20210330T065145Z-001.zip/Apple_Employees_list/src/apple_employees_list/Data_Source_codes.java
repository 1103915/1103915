package apple_employees_list;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Baloch
 */
public class Data_Source_codes {
    String[] employees = new String[6];//_list;
    int index;
    void insert(String data_entry){
       
        if(index<employees.length){
        employees[index++]=data_entry;
                                  }
    }
    void traverse(){
    for(int i=0;i<employees.length;i++){
    System.out.println("["+i+"]"+employees[i]);
                                       }
    }
    String find(String name){
    for(int i=0;i<employees.length;i++){
        if(employees[i]==name){
          return "Name found";
          
                              }
                          }
    return "not found";
                            }
    void delete(int index){
      employees[index]="";  
    for(int i=0;i<employees.length;i++){
     if(index==employees.length){
         employees[i]=employees[i-1];
     }
    }            
                                       }
    
}
